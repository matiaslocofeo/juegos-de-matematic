let currentAnswer = 0;
let points = 0;

function generateQuestion() {
  const difficulty = document.getElementById('difficulty').value;
  let max;
  if (difficulty === 'easy') max = 10;
  else if (difficulty === 'medium') max = 50;
  else max = 100;

  const num1 = Math.floor(Math.random() * max);
  const num2 = Math.floor(Math.random() * max);
  currentAnswer = num1 + num2;

  document.getElementById('question').textContent = \`\${num1} + \${num2} = ?\`;
}

function checkAnswer() {
  const userAnswer = parseInt(document.getElementById('answer').value);
  const result = document.getElementById('result');
  const winMessage = document.getElementById('win-message');

  if (userAnswer === currentAnswer) {
    points++;
    result.textContent = "¡Correcto! 🎉";
    if (points >= 5) {
      winMessage.style.display = 'block';
    } else {
      generateQuestion();
    }
  } else {
    result.textContent = "Incorrecto, inténtalo de nuevo.";
  }

  document.getElementById('answer').value = '';
  document.getElementById('score').textContent = \`Puntos: \${points} / 5\`;
}

function resetGame() {
  points = 0;
  document.getElementById('win-message').style.display = 'none';
  document.getElementById('result').textContent = '';
  document.getElementById('score').textContent = \`Puntos: 0 / 5\`;
  generateQuestion();
}

generateQuestion();